# The script printed in the book that calls itself "queuecrazy.py" is
# actually named "queuepi.py", as you can see a page or two later when
# the book demonstrates how to invoke the script at the shell prompt.
# So the script actually lives at the URL:

# https://github.com/brandon-rhodes/fopnp/blob/m/py3/chapter08/queuepi.py

# Sorry about that!
