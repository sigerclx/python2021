
# Chapter 1

This is a directory of program listings from Chapter 1 of the book:

<dl>
<dt><i>Foundations of Python Network Programming</i></dt>
<dd>
Second Edition, December 2010<br>
by Brandon Rhodes and John Goerzen
</dd>
</dl>

The scripts in this directory **no longer work.**

Google has disabled the network service to which these scripts
connected.  You will only get errors if you try to run them.

But there are now working replacements!  Try out the scripts from the
first chapter of the new Third Edition of the book.  They should be easy
to translate into Python 2 using an automated tool, as explained at:

https://github.com/brandon-rhodes/fopnp/tree/m/py3/chapter01#readme
