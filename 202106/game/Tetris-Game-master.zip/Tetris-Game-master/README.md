# Tetris Game
The game of Tetris. Made with pygame.

You can view the video tutorials on how to create this game here: https://www.youtube.com/watch?v=uoR4ilCWwKA&t=3s

# Run in Gitpod

You can also run Tetris-Game in Gitpod, a free online dev environment for GitHub:

If you're intersted in a paid subscription with GitPod use the coupon code: TECHWITHTIM19


[![Open in Gitpod](https://gitpod.io/button/open-in-gitpod.svg)](https://gitpod.io/#https://github.com/techwithtim/Tetris-Game/blob/master/main.py)
