# Turtle-Race
A randomly simulated turtle race! You can watch different color turtles race across the screen and keep track of the wins/losses of each turtle.

# Run in Gitpod

You can run Turtle-Race in Gitpod, a free online dev environment for GitHub:

If you're intersted in a paid subscription with GitPod use the coupon code: **TECHWITHTIM19**

[![Open in Gitpod](https://gitpod.io/button/open-in-gitpod.svg)](https://gitpod.io/#https://github.com/techwithtim/Turtle-Race/blob/master/main.py)
