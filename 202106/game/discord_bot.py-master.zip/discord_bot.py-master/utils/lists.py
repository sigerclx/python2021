ballresponse = [
  "Yes", "No", "Take a wild guess...", "Very doubtful",
  "Sure", "Without a doubt", "Most likely", "Might be possible",
  "You'll be the judge", "no... (╯°□°）╯︵ ┻━┻", "no... baka",
  "senpai, pls no ;-;"
]
