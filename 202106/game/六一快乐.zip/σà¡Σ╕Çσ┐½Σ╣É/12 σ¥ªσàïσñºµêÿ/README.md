# Introduction
https://mp.weixin.qq.com/s/KuktB_f1vxZCNIAHaaXdsQ

# Environment(Tested)
- Windows10
- Python3.5+(have installed necessary dependencies)

# Usage
- pip install -r requirements.txt
- python Game5.py

# Packages
- pygame
- random
- sys

# Game Display
![giphy](effect/running.gif)